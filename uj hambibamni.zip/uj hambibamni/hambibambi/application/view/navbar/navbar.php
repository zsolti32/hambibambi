<?php

$Path = "./";
if ($_SERVER["REQUEST_URI"] == "/hambibambi/application/view/logreg/loginreg.php") {
    $Path = "../../../";
} elseif ($_SERVER["REQUEST_URI"] == "/hambibambi/application/view/menu/menu.php") {
    $Path = "../../../";
} elseif ($_SERVER["REQUEST_URI"] == "/hambibambi/application/view/contacts/contact.php") {
    $Path = "../../../";
} elseif ($_SERVER["REQUEST_URI"] == "/hambibambi/application/view/logreg/loginregLogin.php") {
    $Path = "../../../";
}

?>
<header>
    <div class="logo">
        <img src="<?= $Path . "assets/img/HambiBambi_Logo.png" ?>" alt="HambiBambi Étterem Logó">
    </div>
    <nav>
        <ul class="navbar">
            <li><a href="<?= $Path . "index.php"; ?>">Kezdőlap</a></li>
            <li><a href="<?= $Path . "application/view/menu/menu.php"; ?>">Étlap</a></li>
            <li><a href="<?= $Path . "application/view/contacts/contact.php"; ?>">Kapcsolat</a></li>
            <?php if (isset($_SESSION['user_id'])) : ?>
                <li><a href="<?= $Path . "application/view/profile/profile.php"; ?>">Profil</a></li>
            <?php else : ?>
                <li><a href="<?= $Path . "application/view/logreg/loginreg.php"; ?>">Belépés / Regisztráció</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
